When launched every single startup will bsod your pc by taskkilling svchost.exe since csrss.exe bsod taskkill has been patched by Microsoft



To remove the bsod startup launch a windows PE or another user then go to C:\Users\your user\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup and delete the .bat file


REEPS 2019 - 2021

Roblox username : itsthereeps Display name: DeadShoot

Minecraft Username: Steveie